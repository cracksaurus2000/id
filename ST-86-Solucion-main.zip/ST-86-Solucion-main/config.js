export const firebaseConfig = {
    apiKey: "AIzaSyAlhxmFuVDRGJjvkFPSS5Q3PCyMiEFxJPw",
    authDomain: "storytellin-72416.firebaseapp.com",
    projectId: "storytellin-72416",
    storageBucket: "storytellin-72416.appspot.com",
    messagingSenderId: "993908358863",
    appId: "1:993908358863:web:63708cad49a4b945ba41ba"
  };